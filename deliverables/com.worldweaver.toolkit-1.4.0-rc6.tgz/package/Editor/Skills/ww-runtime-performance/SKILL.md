---
name: ww-runtime-performance
description: Разбор частых Update, поиска, аллокаций и спавна в горячем пути.
category: performance
keywords: performance FPS lag GC allocation pool производительн тормоз кадр
tools: discover_tools,list_skills,read_skill,inspect_object
source: https://github.com/Besty0728/Unity-Skills/blob/fb7a8d4208671bca1d1013b2776eb2e4917f4964/SkillsForUnity/unity-skills~/skills/performance/SKILL.md
license: MIT
mode: advisory
---

# Разбор частых Update, поиска, аллокаций и спавна в горячем пути

## Рабочий подход
1. Ищи повторные Find/GetComponent, форматирование строк, LINQ и Instantiate в реально часто вызываемом коде. Не объявляй их причиной без профиля.
2. Сначала исправляй доминирующий вклад; изменения архитектуры ради теоретического выигрыша не обязательны. Не переносись автоматически с ECS costs на MonoBehaviour.
3. Проверка: сравни время кадра и GC при одинаковой нагрузке; выдели измеренное улучшение и оставшиеся гипотезы.

## Доступные действия WorldWeaver
При необходимости вызови discover_tools с names: discover_tools,list_skills,read_skill,inspect_object. Это ссылки на существующие команды, а не разрешение на их автоматическое выполнение. После создания читай реальный target, затем применяй зависимые действия отдельным шагом.

## Граница применения
Это справочный Markdown для встроенного агента WorldWeaver. Используй только объявленные в текущем запросе инструменты и их фактические схемы. Навык не добавляет shell, сеть, доступ к секретам, новые разрешения или автоматическое выполнение кода. Если операции нет, дай совет либо подготовь C# для просмотра в поддерживаемом процессе; не выдавай совет за выполненное действие.

## Происхождение
Адаптация для WorldWeaver из Besty0728/Unity-Skills, commit `fb7a8d4208671bca1d1013b2776eb2e4917f4964`. Исходный SHA-256: `305286cc9c448eff977dcd2e36822ab98deabcaf7ba8d6d71e7d92ff64671bec`. Оригинальные REST/MCP-вызовы, режимы bypass и установки зависимостей не перенесены. Лицензия и copyright сохранены в соседней папке LICENSES.
