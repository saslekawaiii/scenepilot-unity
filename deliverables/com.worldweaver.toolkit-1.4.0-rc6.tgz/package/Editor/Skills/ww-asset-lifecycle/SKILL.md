---
name: ww-asset-lifecycle
description: Жизненный цикл assets, GUID и обратимые перемещения ресурсов.
category: assets
keywords: asset GUID meta import ресурс перемещ удален зависимост
tools: catalog_assets,search_project,instantiate_prefab,material_search,material_import,material_apply
source: https://github.com/Besty0728/Unity-Skills/blob/fb7a8d4208671bca1d1013b2776eb2e4917f4964/SkillsForUnity/unity-skills~/skills/asset/SKILL.md
license: MIT
mode: advisory
---

# Жизненный цикл assets, GUID и обратимые перемещения ресурсов

## Рабочий подход
1. Учитывай связку asset и .meta: стабильный GUID сохраняет ссылки. Перемещение не должно заменяться удалением и созданием нового файла.
2. Перед удалением проверь явные ссылки и владельца. Не объявляй файл неиспользуемым только потому, что его имя не встречается в открытой сцене.
3. Проверка: связанные prefab и сцены открываются без missing references; список новых файлов соответствует журналу операции.

## Доступные действия WorldWeaver
При необходимости вызови discover_tools с names: catalog_assets,search_project,instantiate_prefab,material_search,material_import,material_apply. Это ссылки на существующие команды, а не разрешение на их автоматическое выполнение. После создания читай реальный target, затем применяй зависимые действия отдельным шагом.

## Граница применения
Это справочный Markdown для встроенного агента WorldWeaver. Используй только объявленные в текущем запросе инструменты и их фактические схемы. Навык не добавляет shell, сеть, доступ к секретам, новые разрешения или автоматическое выполнение кода. Если операции нет, дай совет либо подготовь C# для просмотра в поддерживаемом процессе; не выдавай совет за выполненное действие.

## Происхождение
Адаптация для WorldWeaver из Besty0728/Unity-Skills, commit `fb7a8d4208671bca1d1013b2776eb2e4917f4964`. Исходный SHA-256: `89b838bebc86d0a801456b2d0f13f09ec1f769ac15f270e719d3a47361bc747c`. Оригинальные REST/MCP-вызовы, режимы bypass и установки зависимостей не перенесены. Лицензия и copyright сохранены в соседней папке LICENSES.
