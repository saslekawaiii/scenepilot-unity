---
name: ww-project-scout
description: Краткое обследование существующего Unity-проекта до генерации новой системы.
category: project
keywords: project scout existing проект обзор packages version folders
tools: discover_tools,list_skills,read_skill,inspect_object
source: https://github.com/Besty0728/Unity-Skills/blob/fb7a8d4208671bca1d1013b2776eb2e4917f4964/SkillsForUnity/unity-skills~/skills/project-scout/SKILL.md
license: MIT
mode: advisory
---

# Краткое обследование существующего Unity-проекта до генерации новой системы

## Рабочий подход
1. Сначала установи версию Unity, pipeline, asmdef, папки кода, активную сцену и уже используемые packages.
2. Найди существующую реализацию нужной механики и проектные соглашения. Не создавай дубли PlayerController, Input или save service вслепую.
3. Проверка: новый план опирается на наблюдаемые имена и типы; неизвестные настройки честно помечены, секретные файлы не нужны.

## Доступные действия WorldWeaver
При необходимости вызови discover_tools с names: discover_tools,list_skills,read_skill,inspect_object. Это ссылки на существующие команды, а не разрешение на их автоматическое выполнение. После создания читай реальный target, затем применяй зависимые действия отдельным шагом.

## Граница применения
Это справочный Markdown для встроенного агента WorldWeaver. Используй только объявленные в текущем запросе инструменты и их фактические схемы. Навык не добавляет shell, сеть, доступ к секретам, новые разрешения или автоматическое выполнение кода. Если операции нет, дай совет либо подготовь C# для просмотра в поддерживаемом процессе; не выдавай совет за выполненное действие.

## Происхождение
Адаптация для WorldWeaver из Besty0728/Unity-Skills, commit `fb7a8d4208671bca1d1013b2776eb2e4917f4964`. Исходный SHA-256: `e5a22fbab556bc3f5b5cb5d3a4a019885a83fb49cf17d0b2b1b9a0664940174d`. Оригинальные REST/MCP-вызовы, режимы bypass и установки зависимостей не перенесены. Лицензия и copyright сохранены в соседней папке LICENSES.
