---
name: ww-assembly-boundaries
description: Границы runtime, editor и тестовых сборок без лишней перестройки проекта.
category: code
keywords: asmdef assembly сборк editor runtime references циклическ
tools: create_node,read_script,draft_script,patch_script,attach_script,inspect_component,add_component,set_component
source: https://github.com/Besty0728/Unity-Skills/blob/fb7a8d4208671bca1d1013b2776eb2e4917f4964/SkillsForUnity/unity-skills~/skills/asmdef/SKILL.md
license: MIT
mode: advisory
---

# Границы runtime, editor и тестовых сборок без лишней перестройки проекта

## Рабочий подход
1. Проверь существующие asmdef и направления ссылок. Runtime не должен ссылаться на UnityEditor; тесты и editor-код живут в отдельных сборках.
2. Добавляй asmdef ради реальной границы или времени компиляции. Не создавай по сборке на каждый маленький класс и не вноси циклические references.
3. Проверка: Editor и Player собираются отдельно, тестовая сборка обнаруживается Test Runner, необязательный пакет не стал скрытой зависимостью.

## Доступные действия WorldWeaver
При необходимости вызови discover_tools с names: create_node,read_script,draft_script,patch_script,attach_script,inspect_component,add_component,set_component. Это ссылки на существующие команды, а не разрешение на их автоматическое выполнение. После создания читай реальный target, затем применяй зависимые действия отдельным шагом.

## Граница применения
Это справочный Markdown для встроенного агента WorldWeaver. Используй только объявленные в текущем запросе инструменты и их фактические схемы. Навык не добавляет shell, сеть, доступ к секретам, новые разрешения или автоматическое выполнение кода. Если операции нет, дай совет либо подготовь C# для просмотра в поддерживаемом процессе; не выдавай совет за выполненное действие.

## Происхождение
Адаптация для WorldWeaver из Besty0728/Unity-Skills, commit `fb7a8d4208671bca1d1013b2776eb2e4917f4964`. Исходный SHA-256: `9b28d9e4054b748c59917ee02fb243377f7186fcd92785e888d3f2119386405d`. Оригинальные REST/MCP-вызовы, режимы bypass и установки зависимостей не перенесены. Лицензия и copyright сохранены в соседней папке LICENSES.
