---
name: ww-ui-toolkit
description: UI Toolkit UXML и USS с корректной жизнью подписок и адаптацией окна.
category: ui
keywords: UIToolkit UXML USS VisualElement ListView ScrollView чат интерфейс
tools: create_ui_element,configure_ui,inspect_component,set_component,draft_script,attach_script
source: https://github.com/Besty0728/Unity-Skills/blob/fb7a8d4208671bca1d1013b2776eb2e4917f4964/SkillsForUnity/unity-skills~/skills/uitoolkit/SKILL.md
license: MIT
mode: advisory
---

# UI Toolkit UXML и USS с корректной жизнью подписок и адаптацией окна

## Рабочий подход
1. Разделяй структуру, стили и поведение. Используй flex sizing и минимальные размеры, чтобы узкое окно не скрывало ввод и кнопки.
2. Регистрацию callbacks делай симметричной и не накапливай её при повторном CreateGUI. Для больших списков учитывай виртуализацию.
3. Проверка: окно можно уменьшить, прокрутка не перескакивает при вводе, Enter и Shift+Enter имеют явное поведение, focus восстанавливается.

## Доступные действия WorldWeaver
При необходимости вызови discover_tools с names: create_ui_element,configure_ui,inspect_component,set_component,draft_script,attach_script. Это ссылки на существующие команды, а не разрешение на их автоматическое выполнение. После создания читай реальный target, затем применяй зависимые действия отдельным шагом.

## Граница применения
Это справочный Markdown для встроенного агента WorldWeaver. Используй только объявленные в текущем запросе инструменты и их фактические схемы. Навык не добавляет shell, сеть, доступ к секретам, новые разрешения или автоматическое выполнение кода. Если операции нет, дай совет либо подготовь C# для просмотра в поддерживаемом процессе; не выдавай совет за выполненное действие.

## Происхождение
Адаптация для WorldWeaver из Besty0728/Unity-Skills, commit `fb7a8d4208671bca1d1013b2776eb2e4917f4964`. Исходный SHA-256: `deb35cefad7e555d28ec23623b6c5b5c797c1f3c6c5fbd1423430ef0d874d1f1`. Оригинальные REST/MCP-вызовы, режимы bypass и установки зависимостей не перенесены. Лицензия и copyright сохранены в соседней папке LICENSES.
