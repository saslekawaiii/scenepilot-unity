# component_set_property

Set a property or field on a component. Supports scalar values, Unity math types (Vector2/3/4, Color, Quaternion), scene object references, and project asset references.

**Signature:** `ComponentSetProperty(string name = null, int instanceId = 0, string path = null, string componentType = null, string propertyName = null, string value = null, string referencePath = null, string referenceName = null, string assetPath = null)`

## Returns

```json
{
  "success": true,
  "gameObject": "Player",
  "component": "Rigidbody",
  "property": "mass",
  "valueSet": "2",
  "valueType": "Single"
}
```

## Value Format Examples

| Type | Example `value` |
|------|----------------|
| float | `"2.5"` |
| int | `"10"` |
| bool | `"true"` / `"false"` / `"1"` / `"0"` |
| Vector2 | `"1.0, 2.0"` |
| Vector3 | `"1.0, 2.0, 3.0"` |
| Vector4 | `"1, 0, 0, 1"` |
| Color (float) | `"1.0, 0.5, 0.0, 1.0"` |
| Color (hex) | `"#FF8800"` |
| Color (named) | `"red"` / `"blue"` / `"white"` etc. |
| Quaternion (euler) | `"0, 90, 0"` |
| Quaternion (xyzw) | `"0, 0.707, 0, 0.707"` |
| Enum | `"ForceMode.Impulse"` or just `"Impulse"` |
| LayerMask | layer name string or int bitmask |
| AnimationCurve | `"linear"` / `"easein"` / `"easeout"` / `"easeinout"` / `"constant"` |

## Notes
- Property name lookup is case-insensitive as a fallback.
- Uses reflection — both C# properties (`CanWrite`) and public fields are supported.
- Uses `Undo.RecordObject` — operation is undoable.
- Snapshots the component state for workflow undo before modifying.

**Prerequisites:** [`execution_result`](../_shared/execution_result.md), [`gameobject_finder`](../_shared/gameobject_finder.md), [`workflow_manager`](../_shared/workflow_manager.md), [`component_type_finder`](../_shared/component_type_finder.md), [`value_converter`](../_shared/value_converter.md), [`skills_common`](../_shared/skills_common.md)

```csharp
using UnityEngine;
using UnityEditor;
using System.Linq;

internal class CommandScript : IRunCommand
{
    public void Execute(ExecutionResult result)
    {
        string name = null; int instanceId = 0; string path = null;
        string componentType = "Rigidbody";
        string propertyName = "mass";
        string value = "2";
        string referencePath = null;
        string referenceName = null;
        string assetPath = null;

        if (string.IsNullOrEmpty(componentType) || string.IsNullOrEmpty(propertyName))
            { result.SetResult(new { error = "componentType and propertyName are required" }); return; }

        var (go, error) = GameObjectFinder.FindOrError(name, instanceId, path);
        if (error != null) { result.SetResult(error); return; }

        var type = ComponentSkills.FindComponentType(componentType);
        if (type == null)
            { result.SetResult(new { error = $"Component type not found: {componentType}" }); return; }

        var comp = go.GetComponent(type);
        if (comp == null)
            { result.SetResult(new { error = $"Component not found: {componentType}" }); return; }

        var prop = type.GetProperties().FirstOrDefault(p => string.Equals(p.Name, propertyName, System.StringComparison.OrdinalIgnoreCase) && p.CanWrite);
        var field = prop == null ? type.GetFields().FirstOrDefault(f => string.Equals(f.Name, propertyName, System.StringComparison.OrdinalIgnoreCase)) : null;

        if (prop == null && field == null)
            { result.SetResult(new {
                error = $"Property/field not found: {propertyName}",
                availableProperties = type.GetProperties().Where(p => p.CanWrite).Select(p => p.Name).ToArray()
            }); return; }

        WorkflowManager.SnapshotObject(comp);
        Undo.RecordObject(comp, "Set Property");

        try
        {
            var targetType = prop?.PropertyType ?? field.FieldType;
            object converted;

            if (!string.IsNullOrEmpty(assetPath))
            {
                converted = AssetDatabase.LoadAssetAtPath(assetPath, targetType);
                if (converted == null)
                    { result.SetResult(new { error = $"Asset not found or type mismatch: '{assetPath}' (expected {targetType.Name})" }); return; }
            }
            else if (!string.IsNullOrEmpty(referencePath) || !string.IsNullOrEmpty(referenceName))
            {
                var (refGo, refErr) = GameObjectFinder.FindOrError(name: referenceName, path: referencePath);
                if (refErr != null) { result.SetResult(new { error = $"Could not resolve reference for {propertyName}" }); return; }
                converted = typeof(UnityEngine.Component).IsAssignableFrom(targetType)
                    ? (object)refGo.GetComponent(targetType)
                    : refGo;
            }
            else
            {
                converted = ComponentSkills.ConvertValue(value, targetType);
            }

            if (prop != null && prop.CanWrite)
                prop.SetValue(comp, converted);
            else if (field != null)
                field.SetValue(comp, converted);
            else
                { result.SetResult(new { error = $"Property {propertyName} is read-only" }); return; }

            EditorUtility.SetDirty(comp);

            result.SetResult(new {
                success = true,
                gameObject = go.name,
                component = componentType,
                property = propertyName,
                valueSet = converted?.ToString() ?? "null",
                valueType = targetType.Name
            });
        }
        catch (System.Exception ex)
        {
            result.SetResult(new { error = ex.Message });
        }
    }
}
```
