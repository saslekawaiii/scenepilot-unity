# texture_set_settings

Set one or more importer settings on a texture asset and reimport it.

## Signature

```
texture_set_settings(
  assetPath: string,
  textureType?: string,
  maxSize?: int,
  filterMode?: string,
  compression?: string,
  mipmapEnabled?: bool,
  sRGB?: bool,
  readable?: bool,
  alphaIsTransparency?: bool,
  spritePixelsPerUnit?: float,
  wrapMode?: string,
  npotScale?: string
) → { success, path, changesApplied, changes }
```

**Prerequisites:** [`execution_result`](../_shared/execution_result.md), [`validate`](../_shared/validate.md), [`workflow_manager`](../_shared/workflow_manager.md)

```csharp
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

internal class CommandScript : IRunCommand
{
    public void Execute(ExecutionResult result)
    {
        string assetPath = "Assets/Textures/hero.png"; // Replace
        string textureType = null;       // e.g. "Sprite"
        int? maxSize = null;             // e.g. 1024
        string filterMode = null;        // e.g. "Point"
        string compression = null;       // e.g. "NormalQuality"
        bool? mipmapEnabled = null;
        bool? sRGB = null;
        bool? readable = null;
        bool? alphaIsTransparency = null;
        float? spritePixelsPerUnit = null;
        string wrapMode = null;
        string npotScale = null;

        if (Validate.Required(assetPath, "assetPath") is object err) { result.SetResult(err); return; }

        var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
        if (importer == null)
            { result.SetResult(new { error = $"Not a texture or asset not found: {assetPath}" }); return; }

        var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
        if (asset != null) WorkflowManager.SnapshotObject(asset);

        var changes = new List<string>();

        if (!string.IsNullOrEmpty(textureType))
        {
            if (System.Enum.TryParse<TextureImporterType>(textureType.Replace(" ", ""), true, out var tt))
            {
                importer.textureType = tt;
                changes.Add($"textureType={tt}");
            }
            else
                { result.SetResult(new { error = $"Invalid textureType: {textureType}. Valid: Default, NormalMap, Sprite, EditorGUI, Cursor, Cookie, Lightmap, SingleChannel" }); return; }
        }

        if (!string.IsNullOrEmpty(filterMode) && System.Enum.TryParse<FilterMode>(filterMode, true, out var fm))
        {
            importer.filterMode = fm;
            changes.Add($"filterMode={fm}");
        }

        if (!string.IsNullOrEmpty(wrapMode) && System.Enum.TryParse<TextureWrapMode>(wrapMode, true, out var wm))
        {
            importer.wrapMode = wm;
            changes.Add($"wrapMode={wm}");
        }

        if (!string.IsNullOrEmpty(npotScale) && System.Enum.TryParse<TextureImporterNPOTScale>(npotScale, true, out var ns))
        {
            importer.npotScale = ns;
            changes.Add($"npotScale={ns}");
        }

        if (mipmapEnabled.HasValue) { importer.mipmapEnabled = mipmapEnabled.Value; changes.Add($"mipmapEnabled={mipmapEnabled.Value}"); }
        if (sRGB.HasValue) { importer.sRGBTexture = sRGB.Value; changes.Add($"sRGB={sRGB.Value}"); }
        if (readable.HasValue) { importer.isReadable = readable.Value; changes.Add($"readable={readable.Value}"); }
        if (alphaIsTransparency.HasValue) { importer.alphaIsTransparency = alphaIsTransparency.Value; changes.Add($"alphaIsTransparency={alphaIsTransparency.Value}"); }
        if (spritePixelsPerUnit.HasValue) { importer.spritePixelsPerUnit = spritePixelsPerUnit.Value; changes.Add($"spritePixelsPerUnit={spritePixelsPerUnit.Value}"); }

        if (maxSize.HasValue || !string.IsNullOrEmpty(compression))
        {
            var platformSettings = importer.GetDefaultPlatformTextureSettings();
            if (maxSize.HasValue) { platformSettings.maxTextureSize = maxSize.Value; changes.Add($"maxSize={maxSize.Value}"); }
            if (!string.IsNullOrEmpty(compression) && System.Enum.TryParse<TextureImporterCompression>(compression, true, out var tc))
            {
                platformSettings.textureCompression = tc;
                changes.Add($"compression={tc}");
            }
            importer.SetPlatformTextureSettings(platformSettings);
        }

        importer.SaveAndReimport();

        { result.SetResult(new { success = true, path = assetPath, changesApplied = changes.Count, changes }); return; }
    }
}
```

## Notes

- `maxSize` and `compression` apply to the **default** platform settings. For per-platform overrides use `texture_set_platform_settings`.
- `SaveAndReimport()` is always called so changes take effect immediately.
- Only supply parameters you want to change; unspecified parameters are left untouched.
