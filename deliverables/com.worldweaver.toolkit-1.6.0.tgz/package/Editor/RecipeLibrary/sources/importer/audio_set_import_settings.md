# audio_set_import_settings

Alternative bridge setter for common audio importer fields.

## Signature

```
audio_set_import_settings(
  assetPath: string,
  forceToMono?: bool,
  loadInBackground?: bool,
  loadType?: string,
  compressionFormat?: string,
  quality?: int
) → { success, assetPath, forceToMono, loadType, compressionFormat }
```

**Prerequisites:** [`execution_result`](../_shared/execution_result.md), [`workflow_manager`](../_shared/workflow_manager.md)

```csharp
using UnityEngine;
using UnityEditor;

internal class CommandScript : IRunCommand
{
    public void Execute(ExecutionResult result)
    {
        string assetPath = "Assets/Audio/bgm.wav"; // Replace
        bool? forceToMono = null;
        bool? loadInBackground = null;
        string loadType = "Streaming";        // DecompressOnLoad | CompressedInMemory | Streaming
        string compressionFormat = "Vorbis";  // PCM | Vorbis | ADPCM
        int? quality = 70;                    // 0 – 100 integer

        var importer = AssetImporter.GetAtPath(assetPath) as AudioImporter;
        if (importer == null) { result.SetResult(new { error = $"Not an audio asset: {assetPath}" }); return; }

        var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
        if (asset != null) WorkflowManager.SnapshotObject(asset);

        if (forceToMono.HasValue)     importer.forceToMono     = forceToMono.Value;
        if (loadInBackground.HasValue) importer.loadInBackground = loadInBackground.Value;

        var settings = importer.defaultSampleSettings;

        if (!string.IsNullOrEmpty(loadType) &&
            System.Enum.TryParse<AudioClipLoadType>(loadType, true, out var parsedLoadType))
            settings.loadType = parsedLoadType;

        if (!string.IsNullOrEmpty(compressionFormat) &&
            System.Enum.TryParse<AudioCompressionFormat>(compressionFormat, true, out var parsedCompression))
            settings.compressionFormat = parsedCompression;

        if (quality.HasValue) settings.quality = quality.Value / 100f;

        importer.defaultSampleSettings = settings;
        importer.SaveAndReimport();

        { result.SetResult(new
        {
            success = true,
            assetPath,
            forceToMono = importer.forceToMono,
            loadType = settings.loadType.ToString(),
            compressionFormat = settings.compressionFormat.ToString()
        }); return; }
    }
}
```

## Notes

- `quality` here is an integer 0–100, unlike `audio_set_settings` which uses a `float` 0.0–1.0. Both map to the same internal field.
- `SaveAndReimport()` is always called.
