# material_get_properties

Get all properties of a material (colors, floats, vectors, textures, integers, and keywords).

**Signature:** `MaterialGetProperties(string name = null, int instanceId = 0, string path = null)`

**Returns:** `{ success, target, shader, renderQueue, keywords, giFlags, properties: { colors, floats, vectors, textures, integers } }`

## Notes
- Each property entry includes `name`, `description`, and `value`. Float and Range properties also include `min` and `max`.
- `keywords` is the raw array of enabled shader keywords.
- Use this to discover property names before calling setters like `material_set_float` or `material_set_color`.

**Prerequisites:** [`execution_result`](../_shared/execution_result.md), [`gameobject_finder`](../_shared/gameobject_finder.md)

```csharp
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

internal class CommandScript : IRunCommand
{
    public void Execute(ExecutionResult result)
    {
        string name       = "Cube"; // target GameObject name
        int    instanceId = 0;
        string path       = null;   // or material asset path like "Assets/Materials/M.mat"

        var (material, go, error) = FindMaterial(name, instanceId, path);
        if (error != null) { result.SetResult(error); return; }

        var shader = material.shader;
        int propertyCount = shader.GetPropertyCount();

        var colors = new List<object>();
        var floats = new List<object>();
        var vectors = new List<object>();
        var textures = new List<object>();
        var integers = new List<object>();

        for (int i = 0; i < propertyCount; i++)
        {
            var propName = shader.GetPropertyName(i);
            var propType = shader.GetPropertyType(i);
            var propDesc = shader.GetPropertyDescription(i);
    
            switch (propType)
            {
                case UnityEngine.Rendering.ShaderPropertyType.Color:
                    var color = material.GetColor(propName);
                    colors.Add(new { name = propName, description = propDesc, value = new { r = color.r, g = color.g, b = color.b, a = color.a } });
                    break;
                case UnityEngine.Rendering.ShaderPropertyType.Float:
                    floats.Add(new { name = propName, description = propDesc, value = material.GetFloat(propName), min = 0f, max = 0f });
                    break;
                case UnityEngine.Rendering.ShaderPropertyType.Range:
                    var range = shader.GetPropertyRangeLimits(i);
                    floats.Add(new { name = propName, description = propDesc, value = material.GetFloat(propName), min = range.x, max = range.y });
                    break;
                case UnityEngine.Rendering.ShaderPropertyType.Vector:
                    var vec = material.GetVector(propName);
                    vectors.Add(new { name = propName, description = propDesc, value = new { x = vec.x, y = vec.y, z = vec.z, w = vec.w } });
                    break;
                case UnityEngine.Rendering.ShaderPropertyType.Texture:
                    var tex = material.GetTexture(propName);
                    textures.Add(new { name = propName, description = propDesc, value = tex != null ? tex.name : null });
                    break;
                case UnityEngine.Rendering.ShaderPropertyType.Int:
                    integers.Add(new { name = propName, description = propDesc, value = material.GetInt(propName) });
                    break;
            }
        }

        { result.SetResult(new {
            success = true,
            target = go != null ? go.name : path,
            shader = shader.name,
            renderQueue = material.renderQueue,
            keywords = material.shaderKeywords,
            giFlags = material.globalIlluminationFlags.ToString(),
            properties = new {
                colors,
                floats,
                vectors,
                textures,
                integers
            }
        }); return; }
    }

    private static (Material mat, GameObject go, object error) FindMaterial(string name, int instanceId, string path)
    {
        if (!string.IsNullOrEmpty(path) && path.EndsWith(".mat"))
        {
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null) return (null, null, new { error = "Material asset not found: " + path });
            return (m, null, null);
        }
        var (go, err) = GameObjectFinder.FindOrError(name, instanceId, path);
        if (err != null) return (null, null, err);
        var rdr = go.GetComponent<Renderer>();
        if (rdr == null) return (null, go, new { error = "No Renderer on " + go.name });
        var mat = rdr.sharedMaterial;
        if (mat == null) return (null, go, new { error = "No material on " + go.name });
        return (mat, go, null);
    }
}
```
